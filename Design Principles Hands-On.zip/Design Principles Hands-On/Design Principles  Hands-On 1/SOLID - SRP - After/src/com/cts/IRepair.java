package com.cts;

public interface IRepair {
	public void processPhoneRepair(String modelName);

	public void processAccessorRepair(String accessoryType);
}
