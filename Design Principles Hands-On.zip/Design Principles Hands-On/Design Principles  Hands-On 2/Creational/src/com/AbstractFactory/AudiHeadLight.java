package com.AbstractFactory;

public class AudiHeadLight extends HeadLight {
	public AudiHeadLight() {
		super("audi headlight");
	}
}